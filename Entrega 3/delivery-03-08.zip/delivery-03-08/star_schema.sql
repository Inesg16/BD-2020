drop table if exists f_replenishment_event cascade;
drop table if exists d_product cascade;
drop table if exists d_date cascade;


CREATE TABLE d_date(
    id_date INTEGER NOT NULL,
    day INTEGER NOT NULL,
    week_day INTEGER,
    week INTEGER,
    month INTEGER NOT NULL,
    year INTEGER NOT NULL,
    CHECK(0 < day AND day < 32),
    CHECK(0 < week AND week < 55),           -- 54 is the max number of weeks in a year
    CHECK (0 < month AND month < 13)
);


CREATE TABLE d_product(
    id_product INTEGER NOT NULL,
    ean BIGINT NOT NULL,
    category VARCHAR (40) NOT NULL NOT NULL,
    CHECK (ean > 999999999999),
    CHECK (ean < 10000000000000)
);


CREATE TABLE f_replenishment_event(
    id_date INTEGER,
    id_product INTEGER,
    units_replaced INTEGER,
    CHECK (units_replaced > 0)
);

CREATE INDEX idx_replenishment_event ON f_replenishment_event (id_date, id_product);

