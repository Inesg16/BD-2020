
-- Table consisting of the total number of replenishments for each category by week day and month

SELECT category, week_day, month, COUNT(*) as replenishments
FROM f_replenishment_event NATURAL JOIN d_date NATURAL JOIN d_product
GROUP BY ROLLUP (category, week_day, month)
ORDER BY (month, week_day)
;

