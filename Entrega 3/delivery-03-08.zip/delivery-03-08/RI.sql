
-- (A) For a given product, there can only be at most 3 secondary suppliers

drop trigger if exists check_max_suppliers_sec_trigger on supplies_sec;

create or replace function check_max_suppliers_sec()
    returns trigger as
$$
    declare prod_num numeric;
begin
    select count(*) into prod_num
    from supplies_sec
    where new.ean = ean;

    if prod_num >= 3 then
        raise exception 'Product % already has 3 secondary suppliers.', new.ean;
    end if;

    return new;
end;
$$ language plpgsql;

create trigger check_max_suppliers_sec_trigger
before update or insert on supplies_sec
for each row execute procedure check_max_suppliers_sec();


-- Example used to test (A) trigger: tried to insert 3 secondary suppliers for the same product
/*
-- deletes
delete from supplies_sec where nif = '123456789';
delete from supplies_sec where nif = '234567890';
delete from supplies_sec where nif = '345678901';
delete from supplies_sec where nif = '456789012';

delete from supplier where nif = '123456789';
delete from supplier where nif = '234567890';
delete from supplier where nif = '345678901';
delete from supplier where nif = '456789012';

delete from product where ean = '1234567890123';

-- inserts
insert into product values('1234567890123', 'descricao muito descritiva', 'Milk');

insert into supplier values('123456789', 'Supplier 1');
insert into supplier values('234567890', 'Supplier 2');
insert into supplier values('345678901', 'Supplier 3');
insert into supplier values('456789012', 'Supplier 4');

insert into supplies_sec values('123456789', '1234567890123');
insert into supplies_sec values('234567890', '1234567890123');
insert into supplies_sec values('345678901', '1234567890123');
insert into supplies_sec values('456789012', '1234567890123');
*/



-- (B) For a given product, a supplier cannot be simultaneously a primary and secondary supplier

-- A new primary supplier can not already be a secondary supplier for the same product
drop trigger if exists check_supplies_prim_trigger on supplies_prim;

create or replace function check_suppliers_prim()
    returns trigger as
$$
begin
    if new.ean in (select ean from supplies_sec where new.nif = nif) then
        raise exception 'Supplier % is already a secondary supplier for the product %.', new.nif, new.ean;
    end if;

    return new;
end;
$$ language plpgsql;

create trigger check_supplies_prim_trigger
before insert on supplies_prim
for each row execute procedure check_suppliers_prim();


-- A new secondary supplier can not be primary supplier for the same product
drop trigger if exists check_supplies_sec_trigger on supplies_sec;

create or replace function check_suppliers_sec()
    returns trigger as
$$
begin
    if new.ean in (select ean from supplies_prim where new.nif = nif) then
        raise exception 'Supplier % is already a primary supplier for the product %.', new.nif, new.ean;
    end if;

    return new;
end;
$$ language plpgsql;

create trigger check_supplies_sec_trigger
before insert on supplies_sec
for each row execute procedure check_suppliers_sec();


-- Example used to test (B) trigger: tried to insert a primary supplier which is already secondary for the same product
--                                   tried to insert a secondary supplier which is already primary for the same product
/*
-- deletes
delete from supplies_sec where nif = '123456789';
delete from supplies_prim where nif = '123456789';
delete from supplies_sec where nif = '987654321';
delete from supplies_prim where nif = '987654321';

delete from supplier where nif = '123456789';
delete from supplier where nif = '987654321';

delete from supplies_prim where ean = '1234567890123';
delete from supplies_sec where ean = '9876543210987';

delete from product where ean = '1234567890123';
delete from product where ean = '9876543210987';

-- inserts
insert into product values('1234567890123', 'descricao muito descritiva', 'Milk');
insert into product values('9876543210987', 'outra descricao fantastica', 'Fishery');

insert into supplier values('123456789', 'Supplier 1');
insert into supplier values('987654321', 'Supplier 2');

-- case where the supplier is already secondary
insert into supplies_sec values('123456789', '1234567890123');
insert into supplies_prim values('123456789', '1234567890123', '12-12-2012');

-- case where the supplier is already primary
insert into supplies_prim values('987654321', '9876543210987', '01-01-2001');
insert into supplies_sec values('987654321', '9876543210987');
*/

