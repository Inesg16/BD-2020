
--  View: supplier_stats returns the number of primary and secondary suppliers for each product

drop view if exists supplier_stats;

create view supplier_stats as
    SELECT t.ean, prim_suppliers, sec_suppliers
    FROM ((SELECT DISTINCT supplies_prim.ean, COUNT(*) as prim_suppliers
    FROM supplies_prim
    GROUP BY supplies_prim.ean) p
    FULL OUTER JOIN
    (SELECT DISTINCT supplies_sec.ean, COUNT(*) as sec_suppliers
    FROM supplies_sec
    GROUP BY supplies_sec.ean) s
    USING (ean)) t
;

-- Example used to test the view
/*
-- deletes
delete from supplies_sec where ean = '1234567890123';
delete from supplies_sec where ean = '2345678901234';

delete from supplies_prim  where ean = '1234567890123';

delete from supplier where nif = '123456789';
delete from supplier where nif = '234567890';
delete from supplier where nif = '345678901';
delete from supplier where nif = '456789012';

delete from product where ean = '1234567890123';
delete from product where ean = '2345678901234';

-- inserts
insert into product values('1234567890123', 'amazing product', 'Fishery');
insert into product values('2345678901234', 'not so amazing product', 'Bakery and Pastry');

insert into supplier values('123456789', '1234567890123');
insert into supplier values('234567890', '1234567890123');
insert into supplier values('345678901', '1234567890123');
insert into supplier values('456789012', '1234567890123');

insert into supplies_prim values('123456789', '1234567890123', '01-01-2001');
insert into supplies_prim values('234567890', '1234567890123', '02-02-2002');

insert into supplies_sec values('345678901', '1234567890123');
insert into supplies_sec values('456789012', '2345678901234');

SELECT * FROM supplier_stats;
*/

