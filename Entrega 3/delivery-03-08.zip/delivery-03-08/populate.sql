
INSERT INTO supermarket VALUES (453821974, 'Good Mourning', '1884 Von Skyway');
INSERT INTO supermarket VALUES (693024895, 'Bitter Drop', '3656 Alessandro Ridge');
INSERT INTO supermarket VALUES (819339626, 'Ocean', '84494 Terrence Point');


INSERT INTO corridor VALUES (453821974, 1, 4.17);
INSERT INTO corridor VALUES (453821974, 2, 12.3);
INSERT INTO corridor VALUES (453821974, 3, 7.7);
INSERT INTO corridor VALUES (693024895, 1, 17.1);
INSERT INTO corridor VALUES (693024895, 2, 15.1);
INSERT INTO corridor VALUES (819339626, 1, 14.19);
INSERT INTO corridor VALUES (819339626, 2, 7.10);
INSERT INTO corridor VALUES (819339626, 3, 20.1);


INSERT INTO shelf VALUES (453821974, 1, 'left', 'floor');
INSERT INTO shelf VALUES (453821974, 1, 'right', 'floor');
INSERT INTO shelf VALUES (453821974, 1, 'left', 'upper');
INSERT INTO shelf VALUES (453821974, 1, 'right', 'upper');
INSERT INTO shelf VALUES (453821974, 2, 'left', 'middle');
INSERT INTO shelf VALUES (453821974, 3, 'left', 'floor');
INSERT INTO shelf VALUES (453821974, 3, 'right', 'floor');

INSERT INTO shelf VALUES (693024895, 1, 'left', 'floor');
INSERT INTO shelf VALUES (693024895, 1, 'right', 'floor');
INSERT INTO shelf VALUES (693024895, 1, 'left', 'middle');
INSERT INTO shelf VALUES (693024895, 1, 'right', 'middle');
INSERT INTO shelf VALUES (693024895, 1, 'left', 'upper');
INSERT INTO shelf VALUES (693024895, 1, 'right', 'upper');
INSERT INTO shelf VALUES (693024895, 2, 'left', 'floor');
INSERT INTO shelf VALUES (693024895, 2, 'left', 'upper');

INSERT INTO shelf VALUES (819339626, 1, 'left', 'floor');
INSERT INTO shelf VALUES (819339626, 1, 'right', 'floor');
INSERT INTO shelf VALUES (819339626, 2, 'left', 'upper');
INSERT INTO shelf VALUES (819339626, 2, 'left', 'middle');
INSERT INTO shelf VALUES (819339626, 3, 'right', 'floor');


INSERT INTO category VALUES ('Beverage');
INSERT INTO category VALUES ('Milk');
INSERT INTO category VALUES ('Soy Milk');
INSERT INTO category VALUES ('Daily Milk');
INSERT INTO category VALUES ('UHT Milk');
INSERT INTO category VALUES ('Water');
INSERT INTO category VALUES ('Soda');
INSERT INTO category VALUES ('Charcuterie');
INSERT INTO category VALUES ('Cheese');
INSERT INTO category VALUES ('Ham');
INSERT INTO category VALUES ('Sausages');
INSERT INTO category VALUES ('Fruit');
INSERT INTO category VALUES ('Fishery');
INSERT INTO category VALUES ('Fish');
INSERT INTO category VALUES ('Shellfish');
INSERT INTO category VALUES ('Bakery and Pastry');
INSERT INTO category VALUES ('Cake');
INSERT INTO category VALUES ('Bread');


INSERT INTO super_category VALUES ('Beverage');
INSERT INTO super_category VALUES ('Milk');
INSERT INTO super_category VALUES ('Charcuterie');
INSERT INTO super_category VALUES ('Fishery');
INSERT INTO super_category VALUES ('Bakery and Pastry');


INSERT INTO simple_category VALUES ('Soy Milk');
INSERT INTO simple_category VALUES ('Daily Milk');
INSERT INTO simple_category VALUES ('UHT Milk');
INSERT INTO simple_category VALUES ('Water');
INSERT INTO simple_category VALUES ('Soda');
INSERT INTO simple_category VALUES ('Cheese');
INSERT INTO simple_category VALUES ('Ham');
INSERT INTO simple_category VALUES ('Sausages');
INSERT INTO simple_category VALUES ('Fruit');
INSERT INTO simple_category VALUES ('Fish');
INSERT INTO simple_category VALUES ('Shellfish');
INSERT INTO simple_category VALUES ('Cake');
INSERT INTO simple_category VALUES ('Bread');


INSERT INTO consists_of VALUES ('Soy Milk', 'Milk');
INSERT INTO consists_of VALUES ('Daily Milk', 'Milk');
INSERT INTO consists_of VALUES ('UHT Milk', 'Milk');
INSERT INTO consists_of VALUES ('Milk', 'Beverage');
INSERT INTO consists_of VALUES ('Water', 'Beverage');
INSERT INTO consists_of VALUES ('Soda', 'Beverage');
INSERT INTO consists_of VALUES ('Cheese', 'Charcuterie');
INSERT INTO consists_of VALUES ('Ham', 'Charcuterie');
INSERT INTO consists_of VALUES ('Sausages', 'Charcuterie');
INSERT INTO consists_of VALUES ('Fish', 'Fishery');
INSERT INTO consists_of VALUES ('Shellfish', 'Fishery');
INSERT INTO consists_of VALUES ('Cake', 'Bakery and Pastry');
INSERT INTO consists_of VALUES ('Bread', 'Bakery and Pastry');


INSERT INTO product VALUES (5246565655758, 'Nestle Powdered Milk 700g', 'Milk');
INSERT INTO product VALUES (5725676780334, 'Alpro Almond Milk 1l', 'Milk');
INSERT INTO product VALUES (2531708764327, 'Gresso UHT Milk 1l', 'UHT Milk');
INSERT INTO product VALUES (8224017154707, 'Parmalat UHT Milk 1l', 'UHT Milk');
INSERT INTO product VALUES (1313943290272, 'Shoyce Soy Milk 500ml', 'Soy Milk');
INSERT INTO product VALUES (3355581033384, 'Vigor Pasteurized Milk 1l', 'Daily Milk');
INSERT INTO product VALUES (4256247647899, 'Auchan Spring Water 6l', 'Water');
INSERT INTO product VALUES (6658445274906, 'Auchan Spring Water 1.5l', 'Water');
INSERT INTO product VALUES (9655000058677, 'Auchan Spring Water 0.5l', 'Water');
INSERT INTO product VALUES (8636604664694, 'Vitalis Spring Water 1.5l', 'Water');
INSERT INTO product VALUES (7139661549293, 'Fastio Spring Water 5l', 'Water');
INSERT INTO product VALUES (1179198742788, 'Pepsi Max 1.75l', 'Soda');
INSERT INTO product VALUES (3951613878585, '7Up 1l', 'Soda');
INSERT INTO product VALUES (8787021792112, 'Valformoso Flamengo Cheese 200g', 'Cheese');
INSERT INTO product VALUES (7818200025864, 'Auchan Edam Cheese 300g', 'Cheese');
INSERT INTO product VALUES (2849161387110, 'Nobre Ham 120g', 'Ham');
INSERT INTO product VALUES (3688081734600, 'Wudy Mortadella 350g', 'Sausages');
INSERT INTO product VALUES (2669355068137, 'Campofrio Frankfurt Sausages 140g', 'Sausages');
INSERT INTO product VALUES (8571131815911, 'Whole Mackerel', 'Fish');
INSERT INTO product VALUES (7235338967732, 'Whole Gilthead Bream', 'Fish');
INSERT INTO product VALUES (3514821883369, 'Whole Seabass', 'Fish');
INSERT INTO product VALUES (7388137468862, 'Frozen Shrimps 1kg', 'Shellfish');
INSERT INTO product VALUES (4393210674751, 'Clams 2kg', 'Shellfish');
INSERT INTO product VALUES (7291006182496, 'Auchan Box 2 Donuts', 'Cake');
INSERT INTO product VALUES (3319223646191, 'Red Velvet', 'Cake');
INSERT INTO product VALUES (1264046062839, 'Loaf of Bread', 'Bread');
INSERT INTO product VALUES (2084652150874, 'Brown Bread 1kg', 'Bread');
INSERT INTO product VALUES (1924664810991, 'Kiwi', 'Fruit');


INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'floor','Soy Milk');
INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'floor','Daily Milk');
INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'floor','UHT Milk');
INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'middle','Water');
INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'upper','Soda');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'floor','Cheese');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'floor','Ham');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'floor','Sausages');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'middle','Fruit');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'upper','Fish');
INSERT INTO displayed_in VALUES (693024895, 1, 'right', 'upper','Shellfish');
INSERT INTO displayed_in VALUES (693024895, 2, 'left', 'floor','Cake');
INSERT INTO displayed_in VALUES (693024895, 2, 'left', 'floor','Bread');
INSERT INTO displayed_in VALUES (693024895, 1, 'left', 'floor','Milk');


INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 5246565655758, 2, 20, 34);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 5725676780334, 2, 18, 23);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 2531708764327, 10, 20, 30);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 8224017154707, 10, 30, 55);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 1313943290272, 2, 10, 43);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'floor', 3355581033384, 1, 10, 88);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'middle', 4256247647899, 6, 10, 45);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'middle', 6658445274906, 5, 12, 44);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'middle', 9655000058677, 3, 6, 42);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'middle', 8636604664694, 5, 5, 90);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'middle', 7139661549293, 4, 8, 16);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'upper', 1179198742788, 2, 8, 65);
INSERT INTO planogram VALUES (693024895, 1, 'left', 'upper', 3951613878585, 1, 5, 89);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'floor', 8787021792112, 3, 5, 67);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'floor', 7818200025864, 4,10, 66);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'floor', 2849161387110, 4, 9, 69);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'floor', 3688081734600, 3, 20, 12);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'floor', 2669355068137, 10, 90, 54);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'upper', 8571131815911, 6, 6, 24);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'upper', 7235338967732, 10, 10, 25);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'upper', 3514821883369, 4, 4, 1);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'upper', 7388137468862, 10, 15, 78);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'upper', 4393210674751, 11, 12, 5);
INSERT INTO planogram VALUES (693024895, 2, 'left', 'floor', 7291006182496, 6, 12, 6);
INSERT INTO planogram VALUES (693024895, 2, 'left', 'floor', 3319223646191, 1, 2, 7);
INSERT INTO planogram VALUES (693024895, 2, 'left', 'floor', 1264046062839, 10, 20, 9);
INSERT INTO planogram VALUES (693024895, 2, 'left', 'floor', 2084652150874, 15, 15, 3);
INSERT INTO planogram VALUES (693024895, 1, 'right', 'middle', 1924664810991, 3, 15, 99);


INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5246565655758, timestamp '20-03-2021 20:00:00', 16);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5246565655758, timestamp '25-03-2021 20:00:00', 17);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5246565655758, timestamp '30-03-2021 12:00:00', 19);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5246565655758, timestamp '01-04-2021 03:00:00', 3);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5725676780334, timestamp '26-03-2021 04:00:00', 16);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 5725676780334, timestamp '29-03-2021 10:00:00', 3);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 2531708764327, timestamp '10-02-2021 23:00:00', 10);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 2531708764327, timestamp '15-03-2021 12:00:00', 5);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 8224017154707, timestamp '30-01-2021 00:00:00', 15);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 8224017154707, timestamp '26-03-2021 00:00:00', 20);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 1313943290272, timestamp '28-02-2021 20:00:00', 4);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 1313943290272, timestamp '25-03-2021 01:00:00', 3);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 3355581033384, timestamp '15-01-2021 15:00:00', 6);
INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'floor', 3355581033384, timestamp '05-02-2021 18:00:00', 9);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'middle', 4256247647899, timestamp '23-12-2020 19:00:00', 8);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'middle', 6658445274906, timestamp '01-11-2020 02:00:00', 10);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'middle', 9655000058677, timestamp '09-02-2021 08:00:00', 4);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'middle', 8636604664694, timestamp '07-03-2021 07:00:00', 2);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'middle', 7139661549293, timestamp '04-04-2021 10:00:00', 4);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'upper', 1179198742788, timestamp '09-04-2021 11:00:00', 7);

INSERT INTO replenish_event VALUES (693024895, 1, 'left', 'upper', 3951613878585, timestamp '30-01-2021 13:00:00', 4);

INSERT INTO replenish_event VALUES (693024895, 1, 'right', 'floor', 8787021792112, timestamp '13-02-2021 19:00:00', 1);

INSERT INTO replenish_event VALUES (693024895, 1, 'right', 'floor', 7818200025864, timestamp '19-03-2021 20:00:00',9);

INSERT INTO replenish_event VALUES (693024895, 1, 'right', 'floor', 2849161387110, timestamp '28-12-2020 22:00:00', 7);

INSERT INTO replenish_event VALUES (693024895, 1, 'right', 'floor', 3688081734600, timestamp '10-04-2021 09:00:00', 16);

INSERT INTO replenish_event VALUES (693024895, 2, 'left', 'floor', 3319223646191, timestamp '09-04-2021 09:00:00', 1);
INSERT INTO replenish_event VALUES (693024895, 2, 'left', 'floor', 3319223646191, timestamp '18-02-2021 08:00:00', 1);
INSERT INTO replenish_event VALUES (693024895, 2, 'left', 'floor', 3319223646191, timestamp '18-01-2021 20:00:00', 2);


INSERT INTO supplier VALUES (275242765, 'Randall Unlimited');
INSERT INTO supplier VALUES (243258884, 'Rockatansky and Co'); --ONLY SUPPLIES AS PRIMARY SUPPLIER (ALL SIMPLE)
INSERT INTO supplier VALUES (113911310, 'Alison Corp');
INSERT INTO supplier VALUES (458291794, 'Stark Industries');
INSERT INTO supplier VALUES (742436606, 'Jeronimo Martins');
INSERT INTO supplier VALUES (387133239, 'Ines Chop Chop'); --ONLY SUPPLIES AS PRIMARY SUPPLIER
INSERT INTO supplier VALUES (946079862, 'Inscape');
INSERT INTO supplier VALUES (705115487, 'Legit Business');
INSERT INTO supplier VALUES (356173526, 'Summoners Rift');
INSERT INTO supplier VALUES (288242860, 'Grey Feast');
INSERT INTO supplier VALUES (747115422, 'Grandfathers Secret'); --ONLY SUPPLIES AS SECONDARY SUPPLIER
INSERT INTO supplier VALUES (264019140, 'Platinum Filling');
INSERT INTO supplier VALUES (606887452, 'Rose Apothecary');
INSERT INTO supplier VALUES (142179512, 'Inverse Flavors');


-- Nestle
INSERT INTO supplies_prim VALUES (946079862, 5246565655758, '16-09-2020');
INSERT INTO supplies_sec VALUES (747115422, 5246565655758);

-- Alpro
INSERT INTO supplies_prim VALUES (387133239, 5725676780334, '19-12-2020');
INSERT INTO supplies_sec VALUES (747115422, 5725676780334);
INSERT INTO supplies_sec VALUES (113911310, 5725676780334);

-- Gresso
INSERT INTO supplies_prim VALUES (243258884, 2531708764327, '01-01-2020');
INSERT INTO supplies_prim VALUES (705115487, 2531708764327, '01-05-2021');
INSERT INTO supplies_sec VALUES (142179512, 2531708764327);

-- Parmalat
INSERT INTO supplies_prim VALUES (243258884, 8224017154707, '01-01-2020');
INSERT INTO supplies_prim VALUES (356173526, 8224017154707, '09-03-2021');
INSERT INTO supplies_sec VALUES (946079862, 8224017154707);

-- Shoyce
INSERT INTO supplies_prim VALUES (243258884, 1313943290272, '01-01-2020');
INSERT INTO supplies_prim VALUES (387133239, 1313943290272, '16-08-2020');
INSERT INTO supplies_sec VALUES (742436606, 1313943290272);

-- Vigor
INSERT INTO supplies_prim VALUES (243258884, 3355581033384, '01-01-2020');
INSERT INTO supplies_prim VALUES (288242860, 3355581033384, '19-11-2020');
INSERT INTO supplies_sec VALUES (747115422, 3355581033384);

-- Auchan 6
INSERT INTO supplies_prim VALUES (142179512, 4256247647899, '12-11-2020');
INSERT INTO supplies_sec VALUES (264019140, 4256247647899);

-- Auchan 1.5
INSERT INTO supplies_prim VALUES (458291794, 6658445274906, '12-11-2020');
INSERT INTO supplies_sec VALUES (275242765, 6658445274906);

-- Auchan 0.5
INSERT INTO supplies_prim VALUES (243258884, 9655000058677, '01-01-2020');
INSERT INTO supplies_prim VALUES (387133239, 9655000058677, '12-11-2021');
INSERT INTO supplies_sec VALUES (742436606, 9655000058677);

-- Vitalis
INSERT INTO supplies_prim VALUES (742436606, 8636604664694, '13-03-2021');
INSERT INTO supplies_sec VALUES (264019140, 8636604664694);

-- Fastio
INSERT INTO supplies_prim VALUES (742436606, 7139661549293, '16-03-2021');
INSERT INTO supplies_sec VALUES (275242765, 7139661549293);

-- Pepsi
INSERT INTO supplies_prim VALUES (243258884, 1179198742788, '01-01-2020');
INSERT INTO supplies_prim VALUES (458291794, 1179198742788, '10-01-2021');
INSERT INTO supplies_sec VALUES (113911310, 1179198742788);

-- 7up
INSERT INTO supplies_prim VALUES (142179512, 3951613878585, '10-02-2021');
INSERT INTO supplies_sec VALUES (747115422, 3951613878585);

-- Valformoso
INSERT INTO supplies_prim VALUES (113911310, 8787021792112, '15-03-2021');
INSERT INTO supplies_sec VALUES (747115422, 8787021792112);

-- Auchan
INSERT INTO supplies_prim VALUES (243258884, 7818200025864, '01-01-2020');
INSERT INTO supplies_prim VALUES (387133239, 7818200025864, '16-08-2021');
INSERT INTO supplies_sec VALUES (946079862, 7818200025864);

-- Nobre
INSERT INTO supplies_prim VALUES (243258884, 2849161387110, '01-01-2020');
INSERT INTO supplies_prim VALUES (458291794, 2849161387110, '24-01-2021');
INSERT INTO supplies_sec VALUES (946079862, 2849161387110);

-- Wudy
INSERT INTO supplies_prim VALUES (243258884, 3688081734600, '01-01-2020');
INSERT INTO supplies_sec VALUES (747115422, 3688081734600);

-- Campofrio
INSERT INTO supplies_prim VALUES (387133239, 2669355068137, '20-04-2021');
INSERT INTO supplies_sec VALUES (113911310, 2669355068137);

-- Mackarel
INSERT INTO supplies_prim VALUES (387133239, 8571131815911, '12-03-2021');
INSERT INTO supplies_sec VALUES (113911310, 8571131815911);

-- Gilthead
INSERT INTO supplies_prim VALUES (243258884, 7235338967732, '01-01-2020');
INSERT INTO supplies_sec VALUES (288242860, 7235338967732);

-- Seabass
INSERT INTO supplies_prim VALUES (606887452, 3514821883369, '15-08-2020');
INSERT INTO supplies_sec VALUES (705115487, 3514821883369);

-- Shrimps
INSERT INTO supplies_prim VALUES (387133239, 7388137468862, '28-11-2020');
INSERT INTO supplies_sec VALUES (288242860, 7388137468862);

-- Clams
INSERT INTO supplies_prim VALUES (243258884, 4393210674751, '01-01-2020');
INSERT INTO supplies_prim VALUES (288242860, 4393210674751, '23-02-2021');
INSERT INTO supplies_sec VALUES (946079862, 4393210674751);

-- Auchan
INSERT INTO supplies_prim VALUES (243258884, 7291006182496, '01-01-2020');
INSERT INTO supplies_prim VALUES (742436606, 7291006182496, '08-03-2020');
INSERT INTO supplies_sec VALUES (264019140, 7291006182496);

-- Red Velvet
INSERT INTO supplies_prim VALUES (113911310, 3319223646191, '01-06-2020');
INSERT INTO supplies_sec VALUES (747115422, 3319223646191);

-- Loaf
INSERT INTO supplies_prim VALUES (243258884, 1264046062839, '01-01-2020');
INSERT INTO supplies_prim VALUES (142179512, 1264046062839, '12-11-2021');
INSERT INTO supplies_sec VALUES (747115422, 1264046062839);

-- Bread
INSERT INTO supplies_prim VALUES (387133239, 2084652150874, '13-09-2020');
INSERT INTO supplies_sec VALUES (275242765, 2084652150874);

-- Kiwi
INSERT INTO supplies_prim VALUES (243258884, 1924664810991, '01-01-2020');
INSERT INTO supplies_prim VALUES (387133239, 1924664810991, '13-08-2020');
INSERT INTO supplies_sec VALUES (275242765, 1924664810991);

