
-- Populates dimension table d_date

CREATE OR REPLACE FUNCTION load_date_dim()
    RETURNS VOID AS
$$
DECLARE date_value TIMESTAMP;
BEGIN
    date_value := '2015-01-01 00:00:00';
    WHILE date_value < '2030-01-01 00:00:00' LOOP
    INSERT INTO d_date(id_date, year, week_day, month, week, day
    ) VALUES (
        EXTRACT(YEAR FROM date_value) * 10000
            + EXTRACT(MONTH FROM date_value) * 100
            + EXTRACT(DAY FROM date_value),
            EXTRACT(YEAR FROM date_value),
            CAST(TO_CHAR(date_value, 'ID') AS INTEGER),
            CAST(EXTRACT(MONTH FROM date_value) AS INTEGER),
            CAST(EXTRACT(WEEK FROM date_value) AS INTEGER),
            CAST(EXTRACT(DAY FROM date_value) AS INTEGER)
        );
        date_value := date_value + INTERVAL '1 DAY';
    END LOOP;
END;
$$ LANGUAGE plpgsql;

SELECT load_date_dim();


-- Populates dimension table d_product

INSERT INTO d_product
SELECT ean%134567, ean, category
FROM product
;


-- Populates dimension table f_replenishment_event

INSERT INTO f_replenishment_event
SELECT id_date, id_product, T.units
FROM replenish_event T
    LEFT OUTER JOIN d_date D1
        ON D1.id_date = EXTRACT(YEAR FROM T.instant) * 10000 + EXTRACT(MONTH FROM T.instant) * 100 + EXTRACT(DAY FROM T.instant)
    LEFT OUTER JOIN d_product D2
        ON D2.id_product = T.ean%134567
;

