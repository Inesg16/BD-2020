-- Query A

SELECT ean, description
FROM product NATURAL JOIN replenish_event
WHERE category = 'Milk'
AND units > 15
AND instant > timestamp '25-03-2021 23:59:59';

-- Query B

SELECT name, nif
FROM supplier NATURAL JOIN (
    (SELECT nif, ean
    FROM supplies_prim)
    UNION
    (SELECT nif, ean
    FROM supplies_sec)
    ) supplies
WHERE ean = '7291006182496'; -- dar valor pretendido

-- Query C

SELECT COUNT(*) AS number_sub_categories
FROM consists_of
WHERE name_super_category = 'Milk';

-- Query D

SELECT name, nif
FROM supplier NATURAL JOIN (
    (SELECT nif, ean
    FROM supplies_prim)
    UNION
    (SELECT nif, ean
    FROM supplies_sec)
    ) supplies NATURAL JOIN product
GROUP BY nif
HAVING COUNT(DISTINCT category) >= ALL (
        SELECT COUNT(DISTINCT category)
        FROM supplier NATURAL JOIN (
            (SELECT nif, ean
            FROM supplies_prim)
            UNION
            (SELECT nif, ean
            FROM supplies_sec)
            ) supplies NATURAL JOIN product
        GROUP BY nif
    );

-- Query E

SELECT DISTINCT name, nif
FROM (supplier NATURAL JOIN supplies_prim) s
WHERE NOT EXISTS(
    SELECT name
    FROM simple_category
    EXCEPT
    SELECT supplies.category
    FROM (supplier NATURAL JOIN supplies_prim NATURAL JOIN product) supplies
    WHERE supplies.nif = s.nif
    );

-- Query F

SELECT DISTINCT p.nif, nr
FROM planogram p JOIN supplies_prim sp ON p.ean = sp.ean
WHERE sp.nif NOT IN (SELECT nif FROM supplies_sec);




