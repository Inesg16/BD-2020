drop table if exists supermarket cascade;
drop table if exists corridor cascade;
drop table if exists shelf cascade;
drop table if exists product cascade;
drop table if exists planogram cascade;
drop table if exists supplier cascade;
drop table if exists supplies_prim cascade;
drop table if exists supplies_sec cascade;
drop table if exists category cascade;
drop table if exists simple_category cascade;
drop table if exists super_category cascade;
drop table if exists consists_of cascade;
drop table if exists displayed_in cascade;
drop table if exists replenish_event cascade;


CREATE TABLE supermarket (
    nif INTEGER,
    name VARCHAR(80) NOT NULL,
    address VARCHAR(255) NOT NULL,
    PRIMARY	KEY(nif),
    CHECK (nif > 99999999),
    CHECK (nif < 1000000000)
);

CREATE TABLE corridor (
    nif INTEGER,
    nr INTEGER,
    width NUMERIC,
    PRIMARY	KEY (nif, nr),
    FOREIGN KEY (nif) REFERENCES supermarket(nif),
    CHECK (nr > 0),
    CHECK (width > 0)
);

CREATE TABLE shelf (
    nif INTEGER,
    nr INTEGER,
    side VARCHAR NOT NULL,
    height VARCHAR NOT NULL,
    PRIMARY	KEY (nif, nr, side, height),
    FOREIGN KEY (nif, nr) REFERENCES corridor(nif, nr),
    CHECK (side in ('left', 'right')),
    CHECK (height in ('upper', 'middle', 'floor'))
);

CREATE TABLE supplier (
    nif INTEGER,
    name VARCHAR(80) NOT NULL,
    PRIMARY KEY (nif),
    CHECK (nif > 99999999),
    CHECK (nif < 1000000000)
);

CREATE TABLE category (
    name VARCHAR(40) NOT NULL,
    PRIMARY KEY (name)
    -- Every category must exist either in the table 'simple_category' or in the table 'super_category'
    -- No category can exist at the same time in the both tables 'simple_category' or 'super_category'
    -- Every category must exist in the table 'displayed_in'
    -- Categories cannot cyclically consist of one another
);

CREATE TABLE product (
    ean BIGINT,
    description VARCHAR(1000) NOT NULL,
    category VARCHAR(40) NOT NULL,
    PRIMARY	KEY (ean),
    FOREIGN KEY (category) REFERENCES category(name), --PENSAR HIERARQUIA CATEGORIA
    CHECK (ean > 999999999999),
    CHECK (ean < 10000000000000)
    -- Every product must exist in the table 'supplies_prim' and 'supplies_sec'
);

CREATE TABLE planogram (
    nif INTEGER,
    nr INTEGER,
    side VARCHAR NOT NULL,
    height VARCHAR NOT NULL,
    ean BIGINT,
    facings INTEGER,
    units INTEGER,
    location INTEGER,
    PRIMARY KEY (nif, nr, side, height, ean),
    FOREIGN KEY (nif, nr, side, height) REFERENCES shelf(nif, nr, side, height),
    FOREIGN KEY (ean) REFERENCES product(ean),
    CHECK (facings > 0),
    CHECK (units > 0),
    CHECK (units >= facings)
);

CREATE TABLE replenish_event (
    nif INTEGER,
    nr INTEGER,
    side VARCHAR NOT NULL,
    height VARCHAR NOT NULL,
    ean BIGINT,
    instant TIMESTAMP NOT NULL,
    units INTEGER,
    PRIMARY KEY (nif, nr, side, height, ean, instant),
    FOREIGN KEY (nif, nr, side, height) REFERENCES shelf(nif, nr, side, height),
    FOREIGN KEY (ean) REFERENCES product(ean),
    CHECK (units > 0),
    CHECK (instant <= NOW())
);

CREATE TABLE supplies_prim (
    nif INTEGER,
    ean BIGINT,
    date DATE NOT NULL,
    PRIMARY KEY (ean, nif),
    FOREIGN KEY (ean) REFERENCES product(ean),
    FOREIGN KEY (nif) REFERENCES supplier(nif)
    -- Every product must exist in the table 'supplies_prim' and 'supplies_sec'
);

CREATE TABLE supplies_sec (
    nif INTEGER,
    ean BIGINT,
    PRIMARY KEY (ean, nif),
    FOREIGN KEY (ean) REFERENCES product(ean),
    FOREIGN KEY (nif) REFERENCES supplier(nif)
    -- Every product must exist in the table 'supplies_prim' and 'supplies_sec'
    -- A product can only have at most 3 secondary suppliers.
);

CREATE TABLE simple_category (
    name VARCHAR(40) NOT NULL,
    PRIMARY KEY (name),
    FOREIGN KEY (name) REFERENCES category(name)
);

CREATE TABLE super_category (
    name VARCHAR(40) NOT NULL,
    PRIMARY KEY (name),
    FOREIGN KEY (name) REFERENCES category(name)
);

CREATE TABLE consists_of (
    name_category VARCHAR(40) NOT NULL,
    name_super_category VARCHAR(40) NOT NULL,
    PRIMARY KEY (name_category),
    FOREIGN KEY (name_category) REFERENCES category(name),
    FOREIGN KEY (name_super_category) REFERENCES super_category(name),
    CHECK (name_category <> name_super_category)
    -- Every super_category must exist in the table 'category'
    -- Categories cannot cyclically consist of one another
);

CREATE TABLE displayed_in (
    nif INTEGER,
    nr INTEGER,
    side VARCHAR NOT NULL,
    height VARCHAR NOT NULL,
    category VARCHAR(40) NOT NULL,
    PRIMARY KEY (nif, nr, side, height, category),
    FOREIGN KEY (nif, nr, side, height) REFERENCES shelf(nif, nr, side, height),
    FOREIGN KEY (category) REFERENCES category(name)
);



